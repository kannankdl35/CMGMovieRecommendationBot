# CMGMovieRecommendationBot

A Telegram bot for movie recommendations powered by TMDb.
