from pyrogram import Client

app=Client('CMGMovieRecommendationBot')

if __name__=='__main__':
    app.run()
